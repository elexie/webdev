var isOpenedModal=false;

/**
names of the 15 images in the html file
*/
var img1Title="";
var img2Title="Dinka Group";
var img3Title="";
var img4Title="";
var img5Title="";

var img6Title="";
var img7Title="";
var img8Title="";
var img9Title="";
var img10Title="";

var img11Title="";
var img12Title="";
var img13Title="";
var img14Title="";
var img15Title="";


function showOverlay(){
  $(".imageBox").hover(function(){
    $(this).find('img').animate({'width':'-=10%'});

    // $("#anImage").stop().animate({'width':"+=50%"});
       // alert("hovered");
      // $(this).find("img").animate({"width":"+=10%"},"slow");
  //    $(this).stop().animate({'width':"+=30%"},'slow');

      //  function(){
      //   alert("hi");
      // });
    });
  // $(".imageBox").mouseout(function(){
  //   $("#imgOverlay").stop().fadeOut();
  // });
}
// retrieves the description of an the clicked image in the .json file
//and displays the description on doubleclick
function showImageModal(){
  var imgUrl="";
  var className="";//class of image clicked
  $('.imageBox').dblclick(function(){
    if(!isOpenedModal){
      $('#bodyOverlay').css('visibility','visible');
      imgUrl=$(this).find('img').attr('src');//save url of clicked image
      className=$(this).attr('class').split(' ')[1];//returns the name of the class without 'imageBox'
      getDescription(className);
      $('#modalImage').attr('src',imgUrl);//change url of modalImage to url of clicked image
      $('#modal').slideDown('slow');
      isOpenedModal=true;
    }
  });

}//end of enlargeImage
// var ht= $("img").height(),
//     wd=$("img").width(),
//     mult=1.5; //change to the no. of times you want to increase your image
//               //size.
//
// $("img").on('mouseenter', function(){
//     $(this).animate({height: ht*mult,
//                      width: wd*mult}, 500);
// });
// $("img").on('mouseleave', function(){
//     $(this).animate({height: ht,
//                      width: wd}, 500);
// })
//returns a digit when given the spelling of a number
function getNumericVal(spelling){
var nums=["one", "two", "three", "four", "five", "six", "seven", "eight", "nine","ten","eleven",
          "twelve","thirteen", "fourteen", "fifteen"];
          return nums.indexOf(spelling);
}
function getDescription(className){
  var array;
   var xhttp=new XMLHttpRequest(); //create an http object
   var returnVal="";
   xhttp.onreadystatechange= function(){
         if(xhttp.readyState==4 && this.status==200){//connection was successful
           array=JSON.parse(xhttp.responseText).descriptions;//stores the description array from the imgDesc file as a js object
           returnVal="return val: "+array[getNumericVal(className)]['desc'];
           console.log(xhttp.responseText);
           // console.log("array[0]: "+array[0]);
            // console.log("array[0][one]: "+array[0]["two"]);

           $("#modalDesc").html(returnVal);
         }//end of f(xhttp.readyState...
   }//end of xhttp.onreadystatechange
   xhttp.open("GET", "../json/imgDesc.json", true);
   xhttp.send();

}//end of getDescription

//enlarges the image on hover and shows an overlay with description
function enlargeImage(){
  /*
  use imageOne and imageBox one as templates since all the other
  boxes have the same size
  */
  var w=$("#imageOne").width();
  var h=$("#imageOne").height();
  $(".imageBox img").mouseover(function(){
      // $(this).stop().animate({width:originalWidth*'1.5%', height:originalHeight*'1.5%'});
      $(this).stop().animate({width:w*1.5, height:h*1.5},500);
      // $(this).parent().find("div").stop().slideDown();
  });
  $(".imageBox img").mouseout(function(){
      // $(this).stop().animate({width:originalWidth, height:originalHeight});
    // $(this).stop().animate({width:w, height:h},500);
    $(this).parent().stop().animate({width:w, height:h},500);

    // $(this).parent().find("div").stop().fadeOut();
  });

}//end of enlargeImage
function enlargeBox(){
	//see example 10 at https://tympanus.net/Tutorials/OriginalHoverEffects/index10.html
  var wt=$("#imageBoxOne").width();
  var ht=$("#imageBoxOne").height();
  $(".imageBox").mouseenter(function(){
    $(this).stop().animate({'width':"+=100%"},'fast');
    $(this).find('div').stop().fadeIn();
  });

  $(".imageBox").mouseleave(function(){
    $(this).stop().animate({'width': '100%'},'fast');
    $(this).find('div').stop().fadeOut();

   });
}//end of enlargeImage
function enlargeBox2(){
	//see example 10 at https://tympanus.net/Tutorials/OriginalHoverEffects/index10.html
  var wt=$("#imageBoxOne").width();
  var ht=$("#imageBoxOne").height();
  $(".imageBox").mouseenter(function(){
    $(this).stop().animate({'width':"+=100%"},'fast');
    $(this).find('div').stop().fadeIn();
  });

  $(".imageBox").mouseleave(function(){
    $(this).stop().animate({'width': '100%'},'fast');
    $(this).find('div').stop().fadeOut();

   });
}//end of enlargeImage
function changeZIndex(){
    $(".imageBox").mouseover(function(){
      $(this).css('z-index','2');
  });
  $(".imageBox").mouseout(function(){
    $(this).css('z-index','0');
});
}
$(document).ready(function(){
showImageModal();
// changeZIndex();
// enlargeImage();
// enlargeBox();
});
